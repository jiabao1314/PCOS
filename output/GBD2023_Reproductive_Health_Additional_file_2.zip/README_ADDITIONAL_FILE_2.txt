Additional file 2: Derived results and reproducible analysis

GBD2023 female infertility attributed to endometriosis and PCOS, ages 15-49, 1990-2023.
Original IHME CSVs are not bundled. Obtain them through the GBD Results Tool under its access and data-use terms. Exact filters, IDs, queries and SHA-256 input hashes are in docs/DATA_ACQUISITION.md and docs/raw_manifest.json. Place licensed originals in the documented data/raw folders. No aligned uncertainty draws were available; derived tables contain point estimates only.

Python 3.12 dependencies are pinned in requirements.txt. After input retrieval, run bash run_all.sh (tectonic is additionally needed for PDFs), or the individual src scripts in the order listed there. All actual-data checks must pass; there is no synthetic research-data fallback. Unit-test fixtures verify arithmetic only. CSVs are UTF-8; rates use per 100,000 females.

reference_composition_decomposition.csv: symmetric decomposition, 20 reference/age specifications, 2 causes, 3 infertility types, 2 starting years and 3 endpoints (720 rows). Components sum to change_D. reference_composition_age_type.csv adds the 7-age breakdown for the main reference (252 rows). subtype_change_robustness.csv also contains fixed-1990-share contrasts, which are path-based and are not symmetric components. Percentages of signed differences may exceed 100 or reverse signs when components offset. Do not add a subtype share to a composition share.

The manuscript, including uncertainty limitations and post hoc analysis disclosure, governs interpretation. Full source reproduction requires IHME input access; bundled result tables alone do not reconstruct the upstream GBD models.
