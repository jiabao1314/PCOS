# PCOS方案A：投稿前精简稿（2026-10-25）

## 推荐稿件

**Human Reproduction（投稿候选稿，并非已正式提交）：**

> Reference-country composition changes the interpretation of PCOS-attributed infertility comparisons: GBD 2023 and UN WPP 2024

研究对象：GBD 2023中中国与其余18个G20主权国家，15–49岁女性，1990–2023年。主结果为PCOS归因不孕的年龄标准化率差、原发/继发分型和参照国家人口构成变化；内异症作为对照病因，仅报告端点敏感性。使用联合国WPP 2024历史人口替换参照国家**各年龄内的国家人口份额**，未替换GBD疾病率。美国NSFG独立分析另行保留，不计入本稿主数据。

## 科学结论（均为模型点估计）

- PCOS中国减18国参考率差变化（1990→2023）：GBD人口份额下 +151.54/10万；其中参照国构成项+88.65（净变化58.5%）。
- UN WPP人口份额下：+150.69/10万；其中构成项+86.76（净变化57.6%）。
- UN 2023人口权重下PCOS继发不孕率差+2.26/10万，固定1990年国家份额后为-48.34/10万。说明结论对**基准定义**敏感，非置信区间。
- GBD联合后验draws尚未获得；因此自定义合并对照/对称分解仅报告点估计。UN人口并未独立核验GBD的不孕率，不能说已完成临床验证。

## 本轮完善了什么

1. 将论文聚焦为**比较基准/估计目标（estimand）敏感性**，减少常规预测与独立NSFG调查叙事的混杂。
2. 在引言中补充与本稿高度相关的已发表研究，特别是《Human Reproduction》2024年PCOS归因不孕GBD论文（Liu等，DOI 10.1093/humrep/dead241）及2025年全球不孕趋势论文（Liang等，DOI 10.1093/humrep/deae292），不宣称该主题“全球首次”。
3. 针对《Human Reproduction》制作extended abstract、主稿、5张独立TIFF/PDF图（400dpi）、4张可编辑Word表、单页Cover Letter与额外材料。
4. 所有未知作者/机构信息、经费、利益冲突、伦理适用性、作者贡献和机构审批均明确用 **XX** 标记，不编造批准或“无利益冲突”。
5. 形成完整TeX源码、衍生数值表、UN人口筛选文件与可重复运行的分析代码；原始受控GBD CSV不公开打包。

## 提交前仍必须由人完成

- **XX作者、作者顺序、邮箱、机构与通讯作者ORCID**；核实每位作者的实质性贡献、最终批准及《Human Reproduction》的作者签字表。
- **XX伦理/免审适用结论**：应由所在机构确认，不擅自写“已获伦理批准”。
- **XX基金/利益冲突/作者贡献/致谢**真实内容。投稿系统通常还要求所有作者在其系统内填报相关信息。
- **XX声明**：原创性、非同时投稿和版权/授权范围等只有作者团队能够最终确认。Cover Letter中的此类语句已保留XX占位。
- 最终核验数值、GATHER清单、引用文献、英文润色及数据使用条件；决定是否上传持久化数据/代码快照并补充DOI。不得把GitHub上的研究稿视为作者已批准终稿。

## 期刊官网格式依据（2026-10-25核验）

- https://academic.oup.com/humrep/pages/Manuscript_Preparation
- https://academic.oup.com/humrep/pages/Clinical_Studies
- 原创研究需要扩展摘要（extended abstract）；对应作者ORCID、作者签字/贡献、Cover Letter、Data availability、分开上传可编辑Word表及JPG/TIFF图。正文双倍行距、连续行号、页码。图形需alt-text。
- 学术范围并不意味着可预期接收；尤其同行已发表相近GBD负担研究，编辑初筛风险仍可能较高。

## 文件夹与用途

- `deliverables/HumanReproduction_SubmissionDraft_XX.pdf`：一区候选主稿。
- `deliverables/ReproductiveHealth_BackupDraft_XX.pdf`：备用，不直接替代期刊定制要求。
- `deliverables/Supplement_ComparatorBenchmark_XX.pdf`：补充材料。
- `deliverables/HumanReproduction_CoverLetter_XX.docx`：投稿信草稿。
- `deliverables/HumanReproduction_EditableTables_XX.docx`：主稿四张可编辑表格。
- `deliverables/HumanReproduction_FigureLegends_XX.docx`：独立图注及alt-text。
- `deliverables/figures/Figure1–Figure5_...tif`：400dpi单图和相同图的矢量PDF。
- `tex/`：完整可编辑LaTeX工程；复制到Overleaf时以`human_reproduction.tex`为主文件。
- `reproducibility/`：衍生CSV、源数据SHA与分析脚本。未包含受控原始GBD数据。

## 固定同步目的地

- Galaxy：https://usegalaxy.eu/histories/view?id=11ac94870d0bb33ad5abd2b59708ab6e ——原始许可数据；本次未新增下载，Galaxy仍待UN WPP历史数据实际上传。
- GitHub：https://github.com/jiabao1314/PCOS ——本次投稿准备版代码、结果、TeX、PDF。
- Google Drive：`2026PCOS` https://drive.google.com/drive/folders/1Db9GIWdXt9eoCOD9oMgNCmoGkiOcQXey ——本次投稿准备包和文件。
- **没有向期刊投稿，没有发送任何邮件。**
