# Replace XX before any journal submission

- [ ] Author 1: legal publication name (XX), affiliation (XX), email (XX), ORCID if available (XX), role (XX), signature (XX)
- [ ] Author 2 and any additional authors: same fields (XX); authorship order agreed jointly
- [ ] Corresponding author: name, current institution/postal address, email and **required ORCID** (XX)
- [ ] Confirm each author's ICMJE eligibility, manuscript approval and accountability; complete Human Reproduction authorship signature form
- [ ] Funding agency/award numbers and funder role (XX); or verified statement if none
- [ ] All commercial, professional and personal conflicts for all authors, including applicable look-back period (XX)
- [ ] Institutional ethics/non-human-subject or waiver applicability and exact decision number where relevant (XX)
- [ ] Acknowledgements and third-party material usage permissions (XX)
- [ ] Confirm title, abstract, all tables, all citations and statements against complete author-reviewed records
- [ ] Confirm not previously published or simultaneously submitted (XX, never assume)
- [ ] Supply permanent code/archive link if available, verify IHME data terms, UN attribution, and availability statement
- [ ] Check all figure TIFFs at journal system preview and provide editable Word table DOCX
- [ ] Remove every remaining `XX` from scientific submission files before clicking Submit

No signatures, ethical approvals, funding, absence of competing interests, authorship or exclusive-submission statements have been invented. The documents are complete editable **drafts** awaiting human authors.
