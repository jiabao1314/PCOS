#!/usr/bin/env python3
"""Design-based reproduction and age-standardized, non-causal associations for NSFG 2022-23.

Inputs: original CDC public-use woman respondent CSV; no identifiable outputs.
Design: full 20 stratum, 80 PSU Taylor first-stage with 60 t d.f.
The age-standardized target is the observed design-weighted US women 20-49 age distribution.
Published-data replication and 2026 exploratory sensitivity only; does not validate GBD.
"""
from pathlib import Path
import hashlib,json, math
import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parent
SRC = ROOT/'nsfg'/'NSFG_2022_2023_FemRespPUFData.csv'
PUB_ZIP = ROOT/'nsfg'/'NSFG-2022-2023-FemRespPUFData.zip'
OUT = ROOT/'audit_output'; OUT.mkdir(exist_ok=True)
expected_zip = 'ef9f0ec715ce7909b50f1ea67958166b2cd1ad3482c4b083174898ec8c7ceaaa'
expected_csv = 'eb10fa3bd11e671b1a3533781a01550261bde9c6b8ad9b17a87dd7250bc131a8'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
 return h.hexdigest()
assert sha(PUB_ZIP)==expected_zip,(sha(PUB_ZIP),expected_zip)
assert sha(SRC)==expected_csv,(sha(SRC),expected_csv)
df=pd.read_csv(SRC,low_memory=False)
assert df.shape == (5586,1912)
assert df.WGT2022_2023.gt(0).all()
strata=df.VEST.to_numpy().astype(int); psu=df.VECL.to_numpy().astype(int)
assert len(set(strata))==20
assert len(set(zip(strata,psu)))==80
assert len(df[(df.AGER>=20)&(df.AGER<=49)])==4855
w=df.WGT2022_2023.to_numpy(float)
dom=(df.AGER.to_numpy()>=20)&(df.AGER.to_numpy()<=49)
ages=df.AGER.to_numpy(int); age_group=np.full(len(df),-1,dtype=int)
for i,(low,high) in enumerate([(20,29),(30,39),(40,49)]):age_group[(ages>=low)&(ages<=high)]=i
broad=np.isin(df.FECUND.to_numpy(),[3,4,5]) | (df.INFERT.to_numpy()==2)
assert broad.shape==(len(df),)
# Full-design 80-PSU summation and Taylor cov using centered PSU linearized totals.
psu_keys=sorted(set(zip(strata,psu)))

def design_cov(phi):
 assert phi.shape[0]==len(df)
 groups={}
 for h,j in psu_keys:
  groups.setdefault(h,[]).append(phi[(strata==h)&(psu==j)].sum(axis=0))
 out=np.zeros((phi.shape[1],phi.shape[1]))
 for h,rows in groups.items():
  rr=np.stack(rows)
  m=rr.shape[0]
  mean=rr.mean(axis=0)
  out += (m/(m-1))*(rr-mean).T@(rr-mean)
 return out

def summarise(disease,age_adjusted=True,other_negative=False):
 diag=df[disease].to_numpy()
 known=dom & np.isin(diag,[1,5]);
 if other_negative:
  other='PCOS' if disease=='ENDO' else 'ENDO'
  known &= (df[other].to_numpy()==5)
 total_domain_n=int(known.sum())
 ncase=int((known&(diag==1)).sum())
 group_ps=[]; phi=[]
 ages_mask=[dom&(age_group==a) for a in range(3)]
 target_tot=np.array([np.sum(w[a]) for a in ages_mask]); target_weights=target_tot/target_tot.sum()
 # target age weights are not arbitrary, but design-weighted 20-49 pooled population.
 for g in [1,5]:
  valid=known&(diag==g)
  if age_adjusted:
   num=np.array([np.sum(w[a&valid]*broad[a&valid]) for a in ages_mask]);
   den=np.array([np.sum(w[a&valid]) for a in ages_mask]);
   if np.any(den==0):return None
   age_p=num/den
   p=float(np.sum(target_weights*age_p));group_ps.append(p)
   # dR = sum_a q_a (dY_ga-p_ga*dN_ga)/N_ga + sum_a (p_ga-R) dN_a/N_total
   psi=np.zeros(len(df))
   for a,am in enumerate(ages_mask):
    psi[am & valid] += w[am&valid]*target_weights[a]*(broad[am&valid]-age_p[a])/den[a]
    psi[am] += w[am]*(age_p[a]-p)/target_tot.sum()
  else:
   num=np.sum(w[valid]*broad[valid]);den=np.sum(w[valid]);p=float(num/den);group_ps.append(p)
   psi=w*valid*(broad.astype(int)-p)/den
  phi.append(psi)
 mat=np.column_stack(phi)
 cov=design_cov(mat)
 p1,p0=group_ps
 d=p1-p0
 covdiff=cov[0,0]+cov[1,1]-2*cov[0,1]
 assert covdiff >= 0
 se=np.sqrt(covdiff)
 ratio=p1/p0
 logpsi=mat[:,0]/p1 - mat[:,1]/p0
 logse=float(np.sqrt(design_cov(logpsi.reshape(-1,1))[0,0]))
 critical=t.ppf(0.975,60)
 return dict(disease=disease,analysis=('age_standardized' if age_adjusted else 'crude')+('_excluding_other_diagnosis' if other_negative else ''),n_all=len(df),n_20_49=int(dom.sum()),eligible_diagnoses=total_domain_n,diagnosed_n=ncase,weighted_p_diagnosed=p1,weighted_p_other=p0,risk_difference_pp=100*d,rd_ci_lower_pp=100*(d-critical*se),rd_ci_upper_pp=100*(d+critical*se),risk_ratio=ratio,rr_lower=ratio*np.exp(-critical*logse),rr_upper=ratio*np.exp(critical*logse),se_diagnosed=float(np.sqrt(cov[0,0])),se_other=float(np.sqrt(cov[1,1])),design_df=60,standard_age_weights=target_weights.tolist(),diagnosed_per_age=[int(np.sum(known & (diag==1) & am)) for am in ages_mask],other_per_age=[int(np.sum(known & (diag==5) & am)) for am in ages_mask])

rows=[]
for d in ['PCOS','ENDO']:
 for age_adjusted in [False,True]:
  for neg in [False,True]:
   rows.append(summarise(d,age_adjusted,neg))
res=pd.DataFrame([{k:v for k,v in r.items() if k not in ('standard_age_weights','diagnosed_per_age','other_per_age')} for r in rows]);res.to_csv(OUT/'nsfg_age_adjusted_results.csv',index=False)
# Published benchmarks (CDC) and original repository expected value
pub={'PCOS':{'diagnosed':0.452,'other':0.171},'ENDO':{'diagnosed':0.330,'other':0.186}}
for d in ['PCOS','ENDO']:
 r=next(x for x in rows if x['disease']==d and x['analysis']=='crude')
 assert abs(r['weighted_p_diagnosed']-pub[d]['diagnosed'])<0.00051,(d,r)
 assert abs(r['weighted_p_other']-pub[d]['other'])<0.00051,(d,r)
repo={'PCOS':{'p1':0.451600938897052,'p0':0.170715385887587,'se1':0.0309015338270722,'se0':0.00633935782281582},'ENDO':{'p1':0.330027858757046,'p0':0.185926610289894,'se1':0.0373583994021629,'se0':0.00694102025719238}}
for d in ['PCOS','ENDO']:
 r=next(x for x in rows if x['disease']==d and x['analysis']=='crude')
 for k,own in [('p1','weighted_p_diagnosed'),('p0','weighted_p_other'),('se1','se_diagnosed'),('se0','se_other')]:
  assert abs(r[own]-repo[d][k])<1e-10,(d,k,r[own],repo[d][k])
check={
'source_zip_SHA256':sha(PUB_ZIP), 'original_csv_SHA256':sha(SRC),
'rows':len(df),'strict_age20_49_n':int(dom.sum()),'sampled_age50_n':int((df.AGER==50).sum()),
'strata':len(set(strata)),'psus':len(psu_keys),'design_df':60,
'benchmark_check':'PASS: CDC 4 current-problem point estimates reproduced to 0.1 percentage point',
'github_repro_check':'PASS: 8 proportions and SEs agree within 1e-10 with independently produced R/Python repository values',
'exploratory':True,
'interpretation':'US cross-sectional diagnosis associations, not external validation of GBD cause-attributed infertility',
'age_adjustment_target':'design-weighted distribution of all US women 20-49 in the NSFG population',
'weight_vector':rows[0]['standard_age_weights'],
'results':rows,
}
(OUT/'audit.json').write_text(json.dumps(check,indent=2,ensure_ascii=False))
print('CHECK: PASS',check['benchmark_check'],check['github_repro_check'])
print(res[['disease','analysis','diagnosed_n','risk_difference_pp','rd_ci_lower_pp','rd_ci_upper_pp','risk_ratio','rr_lower','rr_upper']].to_string(index=False,float_format=lambda x:f'{x:0.3f}'))
