# NSFG 2022–2023: independent original-file verification and age-standardization sensitivity

**Data source:** CDC/NCHS 2022–2023 female respondent public-use data (official CSV ZIP), as retained in the 2026PCOS research archive. Downloaded source ZIP SHA-256: `ef9f0ec715ce7909b50f1ea67958166b2cd1ad3482c4b083174898ec8c7ceaaa`. Expanded CSV SHA-256: `eb10fa3bd11e671b1a3533781a01550261bde9c6b8ad9b17a87dd7250bc131a8`.

**Data quality:** 5,586 records x 1,912 fields; 4,855 strictly aged 20–49 at interview; CDC report includes one aged 50 at interview who was 49 at screening for a 4,856-person domain. The survey uses 20 strata, 80 PSUs and 60 design degrees of freedom. The raw CDC ZIP and expanded CSV hashes were checked against the archived manifest. Eight previously released crude point estimates and design standard errors matched prior R/Python calculations to less than 1e-10.

**Research status:** Unadjusted and exploratory direct age-standardized associations are summarized below. The target population age proportions (20–29, 30–39, 40–49) are 0.33562 / 0.34666 / 0.31773. Both the age-specific estimates and estimated target age composition were included in the linearized variance. CI are pointwise t(60) intervals. This analysis is not preregistered.

| Reported disease diagnosis | Comparison | Prevalence difference, percentage points (95% CI) | Prevalence ratio (95% CI) |
|---|---|---:|---:|
| PCOS | Crude | 28.09 (22.11–34.07) | 2.65 (2.30–3.04) |
| PCOS | Crude, no other diagnosis | 28.32 (21.85–34.80) | 2.72 (2.33–3.17) |
| PCOS | Age std. | 28.57 (22.50–34.65) | 2.67 (2.32–3.07) |
| PCOS | Age std., no other diagnosis | 28.34 (21.95–34.73) | 2.71 (2.32–3.15) |
| ENDO | Crude | 14.41 (6.80–22.02) | 1.78 (1.40–2.25) |
| ENDO | Crude, no other diagnosis | 11.49 (4.16–18.82) | 1.70 (1.29–2.23) |
| ENDO | Age std. | 18.68 (10.38–26.98) | 2.00 (1.59–2.52) |
| ENDO | Age std., no other diagnosis | 15.89 (7.41–24.36) | 1.96 (1.49–2.57) |

**Interpretation:** Broad fertility problems comprise impaired fecundity or infertility using CDC survey recodes. A reported diagnosis is not a causally verified attribution of those problems. Age-standardization increases the endometriosis estimate more than the PCOS estimate; omitting co-diagnosed women does not remove the broad associations. Other variables (diagnosis access, pregnancy intentions, treatment history, educational factors) remain unadjusted. The research question is measurement sensitivity, not cross-country etiology. No GBD jointly indexed posterior draws have been received; do not treat these NSFG confidence intervals as GBD uncertainty.

**Sources:** https://www.cdc.gov/nchs/nsfg/nsfg-2022-2023-puf.htm ; https://www.cdc.gov/nchs/data/hestat/hestat121.htm

**Files:** `src/nsfg_independent_age_standardization.py`, `results/nsfg_age_adjusted_results.csv`, `results/nsfg_age_standardization_audit.json`, `results/nsfg_age_adjusted_forest.pdf`, `latex/manuscript/` (updated main Human Reproduction, Reproductive Health and supplemental TeX projects). Respondent-level records are deliberately excluded from the public analysis package.
