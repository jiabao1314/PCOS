from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parent
r=ROOT/'results';f=ROOT/'manuscript/figures';f.mkdir(exist_ok=True,parents=True)
a=pd.read_csv(r/'all_annual_benchmark_aspr.csv');d=pd.read_csv(r/'symmetric_decomposition_1990_endpoints.csv');s=pd.read_csv(r/'reference_country_shares_1990_2023.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.4,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})

# Figure 5: fully independent denominator-composition audit (disease rates fixed to GBD source)
fig,ax=plt.subplots(figsize=(7.1,3.8))
for source,linestyle,color in [('GBD','-', '#2B507A'),('UN-WPP2024','--','#C46046')]:
 q=a[(a.cause=='Polycystic ovarian syndrome')&(a.subtype=='Total')&(a.source==source)&(a.benchmark=='dynamic')].sort_values('year')
 ax.plot(q.year,q.gap,color=color,linestyle=linestyle,linewidth=2.3,label='GBD population shares' if source=='GBD' else 'UN WPP2024 population shares')
ax.axhline(0,color='#808080',linewidth=.8)
ax.set(xlabel='Calendar year',ylabel='China minus 18-country reference\n(per 100,000 women)',title='PCOS-attributed infertility: source robustness of the pooled reference')
ax.legend(loc='lower right',frameon=False)
ax.grid(alpha=.14,axis='y');fig.tight_layout()
fig.savefig(f/'fig_un_population_benchmark_trends.pdf',bbox_inches='tight');fig.savefig(f/'fig_un_population_benchmark_trends.png',dpi=210,bbox_inches='tight');plt.close(fig)

# Figure 6: all components must sum to signed difference change.
t=d[(d.cause=='Polycystic ovarian syndrome')&(d.subtype=='Total')&(d.end==2023)].set_index('source')
labels=['Chinese rate change','Reference-country rate change','Reference-country share change']
columns=['china_rate_effect','reference_rate_effect','reference_country_composition_effect'];xx=np.arange(3)
fig,ax=plt.subplots(figsize=(7.1,3.8))
for src,dx,c in [('GBD',-.19,'#2B507A'),('UN-WPP2024',+.19,'#C46046')]:
 v=t.loc[src,columns].to_numpy(dtype=float)
 ax.bar(xx+dx,v,width=.37,color=c,label='GBD population shares' if src=='GBD' else 'UN population shares')
 for j,k in enumerate(v):ax.text(j+dx,k+np.sign(k)*5,f'{k:+.1f}',ha='center',va='bottom' if k>=0 else 'top',fontsize=8.2)
ax.axhline(0,color='#575757',linewidth=.85);ax.set_xticks(xx,labels,fontsize=9)
ax.set(ylabel='Contribution (per 100,000 women)',title='Symmetric decomposition, PCOS burden contrast, 1990–2023')
ax.set_ylim(-250,330);ax.legend(loc='upper right',frameon=False,fontsize=8.5)
ax.grid(alpha=.15,axis='y');fig.tight_layout()
fig.savefig(f/'fig_un_population_decomposition.pdf',bbox_inches='tight');fig.savefig(f/'fig_un_population_decomposition.png',dpi=210,bbox_inches='tight');plt.close(fig)

# Supplement Figure: secondary infertility benchmark-specific direction. Do not infer GBD uncertainty.
b=a[(a.cause=='Polycystic ovarian syndrome')&(a.subtype=='Secondary')&(a.year==2023)].copy()
keys=[('GBD','dynamic'),('UN-WPP2024','dynamic'),('UN-WPP2024','fixed1990'),('UN-WPP2024','equal')]
vals=[float(b[(b.source==src)&(b.benchmark==method)].gap.iloc[0]) for src,method in keys]
labels=['Current GBD shares','Current UN shares','Fixed-1990 UN shares','Equal-country shares']
fig,ax=plt.subplots(figsize=(7.0,3.7))
cols=['#2B507A','#C46046','#A9A9A9','#879EAB']
ax.barh(labels,vals,color=cols,height=.63)
for y,v in enumerate(vals):ax.text(v+3 if v>=0 else v-3,y,f'{v:+.2f}',ha='left' if v>=0 else 'right',va='center',fontsize=9.2)
ax.axvline(0,color='#5C5C5C',linewidth=.9);ax.invert_yaxis()
ax.set(xlim=(-155,32),xlabel='China minus 18-country reference (per 100,000)',title='2023 secondary PCOS infertility: direction depends on benchmark')
ax.grid(alpha=.13,axis='x');fig.tight_layout()
fig.savefig(f/'fig_un_secondary_benchmark_sensitivity.pdf',bbox_inches='tight');fig.savefig(f/'fig_un_secondary_benchmark_sensitivity.png',dpi=210,bbox_inches='tight');plt.close(fig)

# Supplement Figure: top country share changes, UN, no extra series to obscure magnitude.
v=s.sort_values('UN_share_change_1990_2023',key=lambda x:abs(x),ascending=False).head(9).sort_values('UN_share_change_1990_2023')
fig,ax=plt.subplots(figsize=(7.1,4.1))
ax.barh(v.country,100*v.UN_share_change_1990_2023,color=np.where(v.UN_share_change_1990_2023>=0,'#408376','#C46046'))
ax.axvline(0,color='#555',linewidth=.85);ax.set(xlabel='Change in reference-country share (percentage points)',title='Population-composition shifts, 1990 to 2023 (UN WPP 2024)')
ax.grid(alpha=.12,axis='x');fig.tight_layout()
fig.savefig(f/'fig_un_country_share_shifts.pdf',bbox_inches='tight');fig.savefig(f/'fig_un_country_share_shifts.png',dpi=210,bbox_inches='tight');plt.close(fig)
print('Generated',len(list(f.glob('fig_un_*'))),'charts')
