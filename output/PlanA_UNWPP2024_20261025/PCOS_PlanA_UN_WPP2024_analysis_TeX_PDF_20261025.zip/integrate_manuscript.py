from pathlib import Path
P=Path(__file__).resolve().parent/'manuscript'
TITLE='Benchmark-sensitive comparisons of PCOS- and endometriosis-attributed infertility: GBD 2023 and an independent UN population audit'
for name in ['main.tex','human_reproduction.tex']:
 p=P/name;t=p.read_text()
 start='\\title{Reference composition and outcome definitions in PCOS- and endometriosis-related infertility comparisons: GBD 2023 and US survey analyses}'
 assert start in t,(name,'title')
 t=t.replace(start, '\\title{'+TITLE+'}')
 for marker,txt in [
  ('\\subsection{Sensitivity analyses and uncertainty}', '\\input{sections/un_population_methods.tex}\n'),
  ('\\subsection{Age patterns and secondary analyses}', '\\input{sections/un_population_results.tex}\n'),
  ('\\input{sections/nsfg_discussion.tex}', '\\input{sections/un_population_discussion.tex}\n')]:
  assert marker in t,(name,marker)
  t=t.replace(marker,txt+marker,1)
 if name=='main.tex':
  marker='\\bibitem{pcos}'
  insert=('\\bibitem{wpp2024} United Nations, Department of Economic and Social Affairs, Population Division. '
    'World Population Prospects 2024, Online Edition: population by five-year age group and sex (midyear). '
    '\\url{https://population.un.org/wpp/}. 2024. Creative Commons Attribution 3.0 IGO.\\n')
 else:
  marker='\\bibitem[Becker et al.(2022)]{eshre}'
  insert=('\\bibitem[UN DESA(2024)]{wpp2024} United Nations, Department of Economic and Social Affairs, Population Division. '
    'World Population Prospects 2024, Online Edition: population by five-year age group and sex (midyear). '
    '\\url{https://population.un.org/wpp/}. 2024. Creative Commons Attribution 3.0 IGO.\\n')
 assert marker in t; t=t.replace(marker,insert.replace('\\n','\n')+marker,1)
 # Clarify data availability without suggesting the UN can verify GBD disease rates.
 marker='\\section*{Ethics approval and consent to participate}'
 # It is also convenient to leave original availability paragraphs untouched, append a verifiable sentence.
 availability='\\subsection*{Availability of data and materials}' if name=='main.tex' else '\\section*{Availability of data and materials}'
 assert availability in t
 t=t.replace(availability,availability+'\nThe independently sourced United Nations WPP 2024 female population table is publicly available from the UN Population Division. The 19-country age--year subset, original-file SHA-256, full crosswalk and analytical source code are provided in the accompanying reproducibility package. The UN data were used for reference-country weights only; original GBD clinical/infertility estimates are governed by IHME conditions.\n',1)
 p.write_text(t)

# Append a WPP methods and results supplement, all paired with main references.
p=P/'supplement.tex';t=p.read_text();assert t.strip().endswith('\\end{document}')
t=t.replace('\\end{document}', '\\input{sections/un_population_supplement.tex}\n\\end{document}')
# supplement has limited cited references? PDF will warn \cite{wpp2024}; remove citation and make full name text if refs not present.
t=t.replace('\\cite{wpp2024}', '(UN Population Division, 2024)')
p.write_text(t)

# Rewrite the Human Reproduction extended abstract to foreground the independent population benchmark.
p=P/'sections/human_reproduction_abstract.tex';t=p.read_text()
t=t.replace('How do reference composition, infertility subtype and outcome/denominator definitions affect the interpretation of PCOS and endometriosis infertility comparisons?', 'Does an independent population source corroborate the demographic-composition component of China-versus-G20 infertility comparisons, and how do infertility definitions affect interpretation?')
t=t.replace('Reference-country shares explained a substantial part of the modeled China--G20 PCOS contrast change, while a separate survey showed that diagnosis-associated estimates varied with definitions and denominators.', 'The reference-composition effect remained substantial under an independent UN population source; country benchmark and infertility subtype still altered the interpretation of the GBD-modelled contrast.')
t=t.replace('Ecological secondary analysis of GBD 2023, 1990--2023, covering 19 sovereign G20 countries and seven female age groups, plus a post hoc cross-sectional NSFG 2022--2023 analysis with 4,855 respondents aged 20--49 at interview.', 'Ecological secondary analysis of GBD 2023, 1990--2023, covering 19 sovereign G20 countries and seven female age groups, independently reweighted with historical UN WPP 2024 population estimates, plus an exploratory US NSFG 2022--2023 analysis of 4,855 respondents.')
t=t.replace('China was compared with 18 other countries using pooling within age, restricted-age standardization, subtype accounting and symmetric endpoint decomposition, with annual-chained sensitivity.', 'China was compared with 18 other countries using within-age pooled rates, symmetric decomposition and independent UN reference-country shares, retaining unchanged GBD age-specific disease rates.')
t=t.replace('The PCOS-related infertility contrast narrowed by 151.54 per 100,000; reference composition contributed 88.65 (58.5\\%), compared with 87.11 (57.5\\%) under annual chaining.', 'The PCOS-related infertility contrast narrowed by 151.54 per 100,000 under GBD population shares and 150.69 under UN shares. The corresponding country-composition terms were 88.65 (58.5\\%) and 86.76 (57.6\\%); the 2023 contrast remained negative with both sources.')
t=t.replace('No jointly aligned GBD draws were obtained.', 'No jointly aligned GBD draws were obtained, and UN demographics cannot independently validate disease-specific modeled prevalence.')
p.write_text(t)

# Make RH abstract consistent; retain already verified NSFG design estimates.
p=P/'main.tex';t=p.read_text()
t=t.replace('GBD 2023 estimates for females aged 15--49 in China and 18 other sovereign G20 countries, 1990--2023, were compared using age-standardized differences and symmetric reference-composition decomposition.', 'GBD 2023 estimates for females aged 15--49 in China and 18 other sovereign G20 countries, 1990--2023, were compared using symmetric reference-composition decomposition and independent UN WPP 2024 country-population shares, with GBD age-specific disease rates fixed.')
t=t.replace('Reference composition contributed +88.65 (58.5\\%), compared with +87.11 (57.5\\%) under annual chaining.', 'Reference composition contributed +88.65 (58.5\\%) using GBD population and +86.76 (57.6\\%) using UN WPP population.')
t=t.replace('Reference composition and estimand choices altered interpretation.', 'An independent demographic source corroborated substantial reference-composition effects and benchmark-sensitive contrasts, but not disease-rate accuracy.')
p.write_text(t)
print('Integrated UN WPP audited analysis into two master manuscripts and supplemental source.')
