# Galaxy PCOS

Target: https://usegalaxy.eu/histories/view?id=11ac94870d0bb33ad5abd2b59708ab6e

This continuation uses the existing GBD 2023 input downloads already preserved in the PCOS Galaxy history and Google Drive, so **there is no new raw dataset to upload in this run**. Research output ZIP is saved to GitHub & Google Drive, and its archive can be imported into Galaxy via the Galaxy URL uploader if desired. This chat has no authenticated Galaxy write action and **no new Galaxy dataset upload is claimed**.

GBD jointly indexed posterior draws: NOT obtained. Alternative external datasets requiring access agreements: NOT obtained.
