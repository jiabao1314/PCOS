# PCOS project: fixed storage and reproducibility destinations

Effective date: 2026-10-25. This is a project instruction supplied by the researcher and should be used in every subsequent PCOS analysis.

## Fixed destinations

1. **Primary data archive / downloaded source files:** Galaxy Europe, history **PCOS**, history ID `11ac94870d0bb33ad5abd2b59708ab6e`: https://usegalaxy.eu/histories/view?id=11ac94870d0bb33ad5abd2b59708ab6e . Upload newly acquired public source datasets and copies of downloadable input files here whenever authorized authenticated upload is available; preserve provenance, original names, version, query settings and SHA-256.
2. **Code, derived results, graphics and SCI manuscript source and deliverables:** GitHub repository **jiabao1314/PCOS**: https://github.com/jiabao1314/PCOS . Commit analysis scripts, pre-specified/exploratory distinctions, data dictionaries, figure sources, TeX and compiled PDFs. Record a commit ID, do not overwrite an earlier verified result silently. Do not publish restricted or identifiable person-level datasets.
3. **Research package, analysis outputs, TeX and PDFs:** Google Drive folder **2026PCOS**, folder ID `1Db9GIWdXt9eoCOD9oMgNCmoGkiOcQXey`: https://drive.google.com/drive/folders/1Db9GIWdXt9eoCOD9oMgNCmoGkiOcQXey . Save the matching reproducibility ZIP and the new manuscript versions. Preserve earlier versions.

## Operational checks

- Before analysis: check the existing Galaxy PCOS history, GitHub main, and Drive 2026PCOS to avoid duplicate datasets and overwriting completed work.
- During acquisition: source ID and hash plus date, source restrictions, units/definitions, and whether the dataset is independent of GBD must be recorded.
- After analysis: execute unit/identity tests, validate figures, compile TeX/PDF, then verify file metadata or content hashes on each actually updated cloud destination.
- If Galaxy upload is unavailable in the active chat (read-only browser tab), **do not falsely mark an upload as completed**. Stage the exact Galaxy-ready archive in Drive 2026PCOS with an explicit pending-upload manifest; keep Galaxy as the target once authenticated write capability exists.
- If GBD jointly aligned posterior draws are not provided, do not manufacture posterior intervals from separate marginal UIs or falsely equate model-based sensitivity to full GBD uncertainty.
- Preserve copyrighted, licensed or person-level source files only in allowed controlled archives and according to applicable provider terms; the public GitHub repository is for permitted code/derived and aggregate outputs.

This file documents the researcher's requested stable workflow; cloud upload success is verified per turn rather than presumed.
