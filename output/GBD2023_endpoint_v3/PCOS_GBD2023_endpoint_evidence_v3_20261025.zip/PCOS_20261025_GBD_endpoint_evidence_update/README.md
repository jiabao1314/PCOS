# PCOS — GBD 2023 terminal-year concordance and alternative-source audit (2026-10-25)

## What is new

- Recomputed China and other 18 G20 country 1990–2023 cause-specific infertility ASPRs from original licensed GBD 2023 CSV and matched same-release female population. Raw data hashes in `results/gbd2023_2023_endpoint_audit.json`.
- Identified abrupt, heterogeneous modelled 2023 endometriosis endpoint changes and partitioned China's increase across primary/secondary infertility and age groups.
- Compared our GBD 2023 modeled Chinese 2023 total with a 2026 publication that used the **same underlying GBD 2023 model**. Identified exact 15–49 age-standardization scaling convention difference (published age-weight sum 0.494902). This is same-source extraction verification, **not independent population validation**.
- Expanded TeX/PDF article candidates (Human Reproduction & Reproductive Health), Supplemental Tables S8/S9 and Figures S7/S8. Those additions are post hoc/exploratory and do not introduce GBD uncertainty intervals.
- Reviewed independent alternatives (WHO 2023, Korean NHIS/HIRA, China Kadoorie Biobank, UK Biobank, All of Us). Restricted access and different outcome definitions prevent using them as direct substitutes for GBD posterior draws or national cause-attributed 2023 validation.

## Reproduce

Use only legitimately acquired licensed data. Extract existing `PCOS_GBD2023_raw_data_2026-10-25.zip` (already archived by the researcher, not included here) under a work directory so that `raw/data/raw/burden_total/*.csv`, `raw/data/raw/population/*.csv`, `raw/data/raw/strata_annual/*.csv`, `raw/data/processed/weights.csv` are available. Copy `src/run_endpoint_audit.py` to the directory root then:

```sh
python3 -m pip install pandas numpy matplotlib
python3 run_endpoint_audit.py
```

To compile, set the working directory to `manuscript_sources/manuscript` and use:

```sh
pdflatex -interaction=nonstopmode main.tex && pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode human_reproduction.tex && pdflatex -interaction=nonstopmode human_reproduction.tex
pdflatex -interaction=nonstopmode supplement.tex && pdflatex -interaction=nonstopmode supplement.tex
```

Latest PDFs are under `compiled/`. The manuscript remains a research draft: actual authors, ethics, funding, all-author approvals, source licensing and full GBD posterior uncertainty remain outstanding.

## Cloud destinations that should never change for PCOS

Original downloaded data -> Galaxy PCOS (history 11ac94870d0bb33ad5abd2b59708ab6e). Derived outputs + TeX/PDF -> GitHub jiabao1314/PCOS and Google Drive 2026PCOS. Use `PCOS_STORAGE_AND_REPRODUCIBILITY_POLICY.md` for verification and permission requirements.
