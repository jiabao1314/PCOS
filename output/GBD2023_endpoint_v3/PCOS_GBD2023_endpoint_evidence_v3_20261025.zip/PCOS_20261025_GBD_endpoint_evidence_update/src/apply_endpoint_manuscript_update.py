from pathlib import Path

base=Path(__file__).resolve().parent/'revision'/'latex'/'manuscript'
sects=base/'sections'; figs=base/'figures'; tabs=base/'tables'
for x in (sects,figs,tabs): x.mkdir(parents=True,exist_ok=True)

(sects/'endo_endpoint_methods.tex').write_text(r'''\paragraph{Additional terminal-year and published-definition cross-check (post hoc).}
Following identification of the unusual final-year endometriosis trajectory, we repeated direct age standardization on the original GBD 2023 age-specific rates in all 19 countries, calculated 2022--2023 year-on-year changes and compared the China endpoint with its own 1991--2022 changes (a descriptive stress test, not a null-hypothesis test). Chinese primary and secondary changes were summed as standard-weighted within-age differences. In addition, we compared the original China modeled case count and published endometriosis rates from an independent 2026 *publication* based on the \emph{same} GBD 2023 release \cite{liu2026}. To harmonize units, we contrasted the seven age weights used as printed (which total 0.494902 for ages 15--49) with the normalized restricted-age weights used throughout this manuscript. Publication-level agreement on a common source is not independent population-based validation, and the published clinical subset has no national denominator.
''',encoding='utf-8')
(sects/'endo_endpoint_results.tex').write_text(r'''\paragraph{GBD 2023 terminal-year source audit.}
China's endometriosis-attributed infertility rate rose from 43.13 to 53.30 per 100,000 between 2022 and 2023 (\(+23.58\%\)); the absolute 15--49 standardized increase was +10.17 per 100,000. Its primary and secondary components were +0.74 and +9.43 per 100,000, respectively, so the latter made up 92.7\% of the \emph{signed modeled rate increment}, not an etiologic fraction. Over the preceding modeled 1991--2022 intervals, China's largest positive annual change was +1.56\%. The 2022--2023 values for endometriosis were +14.82\% in the United States, +11.93\% in Japan and $-0.41$\% in the Republic of Korea, while China's PCOS-related infertility rose only +0.50\% (Supplementary Figures~\ref{fig:endo_yoy} and \ref{fig:endo_age_type}). These heterogeneous model estimates cannot establish a new biological event in 2023.

Our 2023 China total of 181,587.09 modeled endometriosis-infertility cases agrees with the 181,587 cases reported by Liu and colleagues \cite{liu2026}. Their 1990 and 2023 reported age-standardized rates (31.52 and 26.38 per 100,000) closely matched our calculations using the \emph{unrenormalized} seven age weights (31.524 and 26.380); our restricted-15--49 normalized figures were 63.697 and 53.304. The 0.494902 scaling factor explains this otherwise apparently discordant comparison; the two conventions should not be combined as though they were the same estimand. This shared-source numerical cross-check is not independent validation (Supplementary Table~\ref{tab:endo_weight_crosswalk}).
''',encoding='utf-8')
(sects/'endo_endpoint_discussion.tex').write_text(r'''A further GBD 2023 study published in August 2026 reported the same modeled Chinese endometriosis-infertility total and a post-2021 rise, alongside a selected series of 168 clinically confirmed patients \cite{liu2026}. Matching its reported burden required identifying that its published rate scale corresponded numerically to weights for ages 15--49 \emph{without} renormalizing them, whereas our estimand standardizes within the specified age range. Neither the common GBD model output nor the clinical case series can establish independent population prevalence or determine why the 2023 final-year modeled values changed. The large modeled increase in China, Japan and the United States but not the Republic of Korea suggests that input or modelling diagnostics by location are warranted, not that a single healthcare or pandemic mechanism has been demonstrated. The pooled WHO evidence on overall infertility cannot directly validate GBD's cause assignment \cite{who2023}. This terminal-year and scale cross-check was added after outcome inspection and therefore should be treated as exploratory.
''',encoding='utf-8')
(sects/'endo_endpoint_supplement.tex').write_text(r'''\clearpage
\subsection{Supplementary GBD terminal-year source concordance and competing rate definitions}
We reproduced the endometriosis and PCOS rates across all 19 study countries and 34 GBD 2023 years from the original GBD release. This is a check of the \emph{same} model output, not an independent epidemiological replication. National annual rate-change comparisons use year-over-year percentages within the 2023 release. The selection of 2023 for extra scrutiny was post hoc; no change-point significance or pandemic effect is inferred.

\begin{table}[htbp]\centering\small
\caption{Reconciliation of Chinese GBD 2023 endometriosis-related infertility age-standardized rate conventions, per 100,000 women.}\label{tab:endo_weight_crosswalk}
\setlength{\tabcolsep}{5pt}
\begin{tabular}{rrrrr}\toprule
Year & Modelled cases & Restricted 15--49 & Raw partial weights & Liu et al. 2026\\\midrule
1990 & 192,845 & 63.697 & 31.524 & 31.52\\
2023 & 181,587 & 53.304 & 26.380 & 26.38\\\bottomrule
\end{tabular}
\caption*{The sum of published GBD 2023 weights for ages 15--49 is 0.494902. The third column renormalizes to unity within those ages; the fourth uses the original seven weights without renormalization and numerically replicates the reported rate scale. The exact cases and point estimate definitions were inspected from original GBD 2023 CSV.}\end{table}

\begin{table}[htbp]\centering\small
\caption{Selected country endometriosis-attributed infertility year-on-year changes in the 2023 GBD release.}\label{tab:endo_yoy_selected}
\begin{tabular}{lrr}\toprule
Country & 2022--2023 ASPR change (\%) & 1991--2022 max (\%)\\\midrule
China & +23.58 & +1.56\\
United States & +14.82 & +3.88\\
Japan & +11.93 & +1.38\\
Republic of Korea & $-0.41$ & +1.56\\\bottomrule
\end{tabular}
\caption*{Both percentages are from modeled GBD 2023 age-standardized rates restricted to 15--49, not independent survey measurements or posterior draws. Historical maxima are for descriptive model comparison only.}\end{table}

\begin{figure}[htbp]\centering\includegraphics[width=.9\textwidth]{figures/fig_endo_2023_g20_yoy.pdf}
\caption{GBD 2023 endpoint model changes in endometriosis-attributed infertility rates across all 19 G20 countries, 2022--2023. Positive and negative bars are changes in modeled 15--49 ASPR, not evidence of population incidence changes.}\label{fig:endo_yoy}\end{figure}
\begin{figure}[htbp]\centering\includegraphics[width=.9\textwidth]{figures/fig_endo_china_age_type_2023.pdf}
\caption{Standard-weighted five-year-age and infertility-type contributions to the modeled Chinese endometriosis-attributed infertility 2022--2023 rate change. Sum of primary and secondary contributions equals the total 15--49 ASPR change (10.1723 per 100,000).}\label{fig:endo_age_type}\end{figure}
''',encoding='utf-8')

for file in ['main.tex','human_reproduction.tex']:
    path=base/file
    text=path.read_text(encoding='utf-8')
    marker='Fixed-share contrasts are a separate, order-specific sensitivity, not an interchangeable estimate of the symmetric share component.'
    assert text.count(marker)==1
    text=text.replace(marker,marker+'\n\n\\input{sections/endo_endpoint_methods.tex}')
    marker='China\'s endometriosis estimate rose by 23.6\\% in the last year, so the terminal comparison does not summarize a stable trajectory.'
    assert text.count(marker)==1
    text=text.replace(marker,marker+'\n\n\\input{sections/endo_endpoint_results.tex}')
    marker='Retaining the earlier endpoints and full annual trajectories makes the limitation visible.'
    assert text.count(marker)==1
    text=text.replace(marker,marker+'\n\n\\input{sections/endo_endpoint_discussion.tex}')
    bib='\\begin{thebibliography}{99}'
    assert text.count(bib)==1
    if file=='main.tex':
       ins=(r'\bibitem{liu2026} Liu Y, Hua S, Wang F, Zhou C, Wan G, Tang W. Endometriosis-associated infertility in China: epidemiological trends, future projection, and real-world clinical insights. \emph{Int J Womens Health}. 2026;18:622604. \href{https://doi.org/10.2147/IJWH.S622604}{doi:10.2147/IJWH.S622604}.'+'\n'+r'\bibitem{who2023} World Health Organization. Infertility prevalence estimates, 1990--2021. WHO; 2023. \url{https://www.who.int/publications/i/item/978920068315}.'+'\n')
    else:
       ins=(r'\bibitem[Liu et al.(2026)]{liu2026} Liu Y, Hua S, Wang F, Zhou C, Wan G, Tang W. Endometriosis-associated infertility in China: epidemiological trends, future projection, and real-world clinical insights. \emph{Int J Womens Health}. 2026;18:622604. \href{https://doi.org/10.2147/IJWH.S622604}{doi:10.2147/IJWH.S622604}.'+'\n'+r'\bibitem[WHO(2023)]{who2023} World Health Organization. Infertility prevalence estimates, 1990--2021. WHO; 2023. \url{https://www.who.int/publications/i/item/978920068315}.'+'\n')
    text=text.replace(bib,bib+'\n'+ins)
    path.write_text(text,encoding='utf-8')
path=base/'supplement.tex'
text=path.read_text(encoding='utf-8')
assert text.count('\\end{document}')==1
text=text.replace('\\end{document}','\\input{sections/endo_endpoint_supplement.tex}\n\\end{document}')
path.write_text(text,encoding='utf-8')
for p in (Path(__file__).resolve().parent/'results').glob('fig*.pdf'):
    (figs/p.name).write_bytes(p.read_bytes())
print('Applied manuscript source insertions')
