#!/usr/bin/env python3
"""Transparent GBD2023 terminal-year concordance/robustness audit.
This script does not create posterior draws or interpret same-source replication
as independent biological validation. Source data remain in the local raw archive.
"""
import hashlib
import json
import pathlib
import sys
from datetime import date

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = pathlib.Path(__file__).resolve().parent
raw = root / "raw" / "data" / "raw"
out = root / "results"
out.mkdir(parents=True, exist_ok=True)

def read_one(folder):
    files = list((raw / folder).glob("*.csv"))
    assert len(files) == 1, (folder, files)
    return pd.read_csv(files[0]), files[0]

burden, bpath = read_one("burden_total")
strata, spath = read_one("strata_annual")
people, ppath = read_one("population")
wtpath = root / "raw" / "data" / "processed" / "weights.csv"
weights = pd.read_csv(wtpath)
assert weights["age_name"].tolist() == ["15-19","20-24","25-29","30-34","35-39","40-44","45-49"]
assert burden.shape[0] == 36176 and people.shape[0] == 4522 and strata.shape[0] == 36176
assert burden.sex_id.eq(2).all() and burden.rei_id.eq(198).all()
assert strata.rei_id.isin([220,221]).all()
assert burden.year.min() == 1990 and burden.year.max() == 2023
for frame, keys in [(burden,['location_id','year','age_id','cause_id','rei_id','measure_id','metric_id']),
                    (strata,['location_id','year','age_id','cause_id','rei_id','measure_id','metric_id'])]:
    assert not frame.duplicated(keys).any()
assert not people.duplicated(['location_id','year','age_id']).any()
wsum = float(weights.weight.sum())
assert abs(wsum-.494902) < 1e-9
wnorm = {k+' years': float(v/wsum) for k,v in zip(weights.age_name, weights.weight)}
wraw = {k+' years': float(v) for k,v in zip(weights.age_name, weights.weight)}

# Original rate consistency with matching same-release female population.
num = burden[(burden.measure_id==5)&(burden.metric_id==1)].copy()
rate = burden[(burden.measure_id==5)&(burden.metric_id==3)].copy()
key = ['location_id','year','age_id','cause_id','rei_id','measure_id']
matched = num.merge(rate[key+['val']].rename(columns={'val':'rate_original'}), on=key, validate='one_to_one')
matched = matched.merge(people[['location_id','year','age_id','val']].rename(columns={'val':'population'}),on=['location_id','year','age_id'],validate='many_to_one')
matched['rate_recomputed'] = matched.val/matched.population*1e5
max_rate_abs_error = float(np.max(np.abs(matched.rate_recomputed-matched.rate_original)))
assert max_rate_abs_error < 1e-7, max_rate_abs_error

base = burden[(burden.measure_id==5)&(burden.metric_id==3)].copy()
base['w_normal'] = base.age_name.map(wnorm)
base['w_whole_subset'] = base.age_name.map(wraw)
assert base.w_normal.notna().all()
base['weighted'] = base.val*base.w_normal
base['weighted_unscaled'] = base.val*base.w_whole_subset
rates = base.groupby(['location_id','location_name','cause_id','cause_name','year'],as_index=False).agg(
    asp_15_49=('weighted','sum'), aspect_whole_subset=('weighted_unscaled','sum'))
rates = rates.sort_values(['location_name','cause_name','year'])
rates['yoy_pct'] = rates.groupby(['location_name','cause_id'])['asp_15_49'].pct_change()*100
rates['previous_year'] = rates.year - 1
rates.to_csv(out/'gbd2023_19country_annual_standardized_rates.csv',index=False)

stress = []
for (loc,cause), g in rates.groupby(['location_name','cause_name']):
    last = g.loc[g.year==2023].iloc[0]
    old = g.loc[(g.year>=1991)&(g.year<=2022),'yoy_pct']
    assert len(old)==32
    stress.append({
        'location':loc, 'cause':cause, 'aspr_2022':float(g.loc[g.year==2022,'asp_15_49'].iloc[0]),
        'aspr_2023':float(last.asp_15_49),'yoy_pct_2023':float(last.yoy_pct),
        'historical_max_yoy_pct_1991_2022':float(old.max()),
        'historical_min_yoy_pct_1991_2022':float(old.min()),
        'historical_p95_yoy_pct_1991_2022':float(old.quantile(.95)),
        'above_pre2023_max':bool(last.yoy_pct > old.max()),
        'below_pre2023_min':bool(last.yoy_pct < old.min())})
stress=pd.DataFrame(stress).sort_values(['cause','yoy_pct_2023'],ascending=[True,False])
stress.to_csv(out/'gbd2023_19country_2023_yoy_stress_test.csv',index=False)

# Subtype-specific decomposition of absolute rate change, not causal attribution.
ch=strata[(strata.location_name=='China')&(strata.measure_id==5)&(strata.cause_id==607)&strata.year.isin([2022,2023])].copy()
ch=ch.merge(people[['location_id','year','age_id','val']].rename(columns={'val':'population'}),on=['location_id','year','age_id'],validate='many_to_one')
ch['aspr_component'] = ch.val/ch.population*1e5*ch.age_name.map(wnorm)
wide=ch.pivot_table(index=['rei_id','rei_name','age_id','age_name'],columns='year',values='aspr_component').reset_index()
wide['delta_component'] = wide[2023]-wide[2022]
wide.columns=[str(a) for a in wide.columns]
wide.to_csv(out/'china_endometriosis_2022_2023_age_subtype_components.csv',index=False)
changes=wide.groupby('rei_id').delta_component.sum().to_dict()
assert abs(changes[220]+changes[221]-(53.30370369586087-43.131356908766705))<1e-6

# Published GBD2023 external article values: shared source, different weight scaling.
ch_rate = rates[(rates.location_name=='China')&(rates.cause_id==607)]
cross=[]
for yr,pub in [(1990,31.52),(2023,26.38)]:
    row=ch_rate[ch_rate.year==yr].iloc[0]
    cross.append({'year':yr,'china_restricted_age_standardized_per100k':float(row.asp_15_49),
                  'published_full_weight_subset_per100k':pub,
                  'reconstructed_unrenormalized_per100k':float(row.aspect_whole_subset),
                  'weight_sum_15_49':wsum,
                  'difference_from_published':float(row.aspect_whole_subset-pub)})
cross=pd.DataFrame(cross)
assert max(abs(cross.difference_from_published)) < 0.01
cross.to_csv(out/'china_endometriosis_published_rate_crosswalk.csv',index=False)
chcases = num[(num.location_name=='China')&(num.cause_id==607)].groupby('year').val.sum()
assert abs(chcases.loc[2023]-181587) < 1

# Produce separate charts, unmodified official model point values only.
plt.rcParams.update({'font.size':10,'axes.titlesize':12})
fig,ax=plt.subplots(figsize=(9,5.1))
for place in ['China','Japan','Republic of Korea','United States of America']:
    sub=rates[(rates.location_name==place)&(rates.cause_id==607)&(rates.year>=2010)]
    ax.plot(sub.year,sub.asp_15_49,marker='o',markersize=3,label=place)
ax.set(xlabel='GBD model calendar year',ylabel='Endometriosis-attributed infertility ASPR\n(15–49, per 100,000)',title='GBD 2023 endometriosis endpoint sensitivity (same-source modeled estimates)')
ax.legend(loc='best',fontsize=8)
ax.grid(alpha=.15)
fig.tight_layout()
fig.savefig(out/'fig_endo_model_2010_2023.pdf')
fig.savefig(out/'fig_endo_model_2010_2023.png',dpi=200)
plt.close(fig)

fig,ax=plt.subplots(figsize=(10,6.2))
g=stress[stress.cause=='Endometriosis'].sort_values('yoy_pct_2023')
ax.barh(g.location,g.yoy_pct_2023)
ax.axvline(0,color='black',lw=.9)
ax.set(xlabel='Modelled ASPR change 2022→2023 (%)',title='Country-specific final-year endometriosis changes (GBD 2023; 19 G20 members)')
ax.grid(axis='x',alpha=.15)
fig.tight_layout()
fig.savefig(out/'fig_endo_2023_g20_yoy.pdf')
fig.savefig(out/'fig_endo_2023_g20_yoy.png',dpi=200)
plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.7))
plotdata=wide.pivot(index='age_name',columns='rei_name',values='delta_component')
plotdata=plotdata.loc[[k+' years' for k in weights.age_name]]
ax.bar(plotdata.index,plotdata['Primary infertility'],label='Primary')
ax.bar(plotdata.index,plotdata['Secondary infertility'],bottom=plotdata['Primary infertility'],label='Secondary')
ax.set(xlabel='Age group',ylabel='Contribution to China ASPR change (per 100,000)',title='China 2022→2023 age-by-infertility-type decomposition (GBD model)')
ax.tick_params(axis='x',rotation=35)
ax.legend()
fig.tight_layout()
fig.savefig(out/'fig_endo_china_age_type_2023.pdf')
fig.savefig(out/'fig_endo_china_age_type_2023.png',dpi=200)
plt.close(fig)

# High-level verification output. All derived rates are point estimates without posterior uncertainty.
q = {k:rates[(rates.location_name==k)&(rates.cause_id==607)&(rates.year==2023)].iloc[0] for k in ['China','Japan','Republic of Korea','United States of America']}
cc = rates[(rates.location_name=='China')&(rates.cause_id==607)].set_index('year').asp_15_49
pc = rates[(rates.location_name=='China')&(rates.cause_id==605)].set_index('year').asp_15_49
report={
    'generated_date':'2026-10-25',
    'data_release':'GBD 2023, all input files verified and kept in private archive',
    'location_count':int(rates.location_name.nunique()),
    'weights_sum_reproductive_ages':wsum,
    'max_rate_number_denominator_abs_mismatch':max_rate_abs_error,
    'reported_china_2023_endo_cases':181587,
    'recomputed_china_2023_endo_cases':float(chcases.loc[2023]),
    'china_endo_aspr_2022':float(cc.loc[2022]),
    'china_endo_aspr_2023':float(cc.loc[2023]),
    'china_endo_yoy_2023_pct':float((cc.loc[2023]/cc.loc[2022]-1)*100),
    'china_endo_aspr_delta':float(cc.loc[2023]-cc.loc[2022]),
    'china_endo_secondary_delta':changes[221],
    'china_endo_secondary_fraction_of_signed_delta':float(changes[221]/(cc.loc[2023]-cc.loc[2022])),
    'china_pcos_yoy_2023_pct':float((pc.loc[2023]/pc.loc[2022]-1)*100),
    'china_endo_yoy_historical_max_1991_2022':float(stress[(stress.location=='China')&(stress.cause=='Endometriosis')].historical_max_yoy_pct_1991_2022.iloc[0]),
    '2023_endo_country_yoy_pct':{c:float(row.yoy_pct) for c,row in q.items()},
    'source_hashes':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [bpath, spath, ppath, wtpath]},
    'independent_validation_completed':False,
    'jointly_aligned_gbd_draws_acquired':False,
    'notes':'The 2026 Liu et al. paper reuses GBD 2023; cross-check proves numeric concordance of source points and weight conventions only, not independent evidence.'
}
(out/'gbd2023_2023_endpoint_audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
